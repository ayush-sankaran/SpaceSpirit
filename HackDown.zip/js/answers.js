function myFunction(){
    var question = document.getElementById("question");
    document.write(question);
}