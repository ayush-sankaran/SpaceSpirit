<html>
<head>
	<meta charset="utf-8">
	<meta name = "viewport" content = "width=device-width">
	<meta name = "description" content = "Affordable and professional web design">
	<meta name = "keywords" content = "web design, affordable web design, professional web design">
	<meta name = "author" content = "Brad Tavery">
	<title>Space Spirit | Articles</title>
	<link rel = "stylesheet" href= "./css/style1.css"> 
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/bootstrap.css" rel="stylesheet">
</head>
<body>
	<header id = "toolbar">
		 <div class = "container">
		 	<div id = "branding">
		 		<h1 id = "logo"><span class = "highlight"><a href = "index.php"><img src = "img/newLogo.png"></a></span></h1>
		 	</div>
		 	<nav>
		 		<ul>
		 			<li><a href = "index.php">Home</a></li>
		 			<li class = "current"><a href = "about.php">Articles</a></li>
		 			<li><a href = "answers.php">Answers</a></li>
		 			<li><a href = "#contact" data-toggle = "modal">Form</a></li>
		 		</ul>
		 	</nav>
		 </div>
	</header>

	<section id = "newsletter">
		<div class = "container">
			<h1>Subscribe to our newsletter!</h1>
			<form>
				<input types = "email" placeholder="Enter Email....">
				<button type = "submit" class = "button_1">Subscribe</button>
			</form>
		</div>
	</section>

	<section id = "main">
		<div class = "container">
			<article id = "main-col">
				<h1 class = "page-title" id = "page">Articles</h1>
				<h2 id = "title">"NASA's Last Rocket"</h2>
				<h3 id = "author">By: David B. Brown</h3>
				<p id = "content">
					Eleven years in the making, the most powerful NASA-built rocket since the Apollo program at last stands upright. Framed by the industrial test platform to which it is mounted, the Space Launch System’s core section is a gleaming, apricot-colored column cast into relief by twisting pipes and steel latticework. The rocket is taller than the Statue of Liberty, pedestal and all, and is the cornerstone of NASA’s astronaut ambitions. The launch vehicle is central to the agency’s Artemis program to return humans to the lunar surface, and later, land them on Mars. On Thursday, NASA set out for a second time to prove that the Space Launch System is ready to take flight, conducting a continuous “hot fire” of its engines for more than eight minutes. The test appears to have gone well, following an earlier test in January that cut off after about 67 seconds because of errors and equipment problems. The rocket’s next stop will be Kennedy Space Center in Florida, and as early as November, the launchpad. It is expected to lift a capsule called Orion on a path around the moon and back. Its first crewed mission is planned for 2023. That flight will be the first to lift astronauts beyond low-Earth orbit since 1972. Indeed, it will send astronauts farther into space than any human has gone before.And yet far from being a bold statement about the future of human spaceflight, the Space Launch System rocket represents something else: the past, and the end. This is the last class of rocket that NASA is ever likely to build.Seeing it launch, though, will actually mean something. While NASA has long desired to return astronauts to deep space, it could not. The agency lacked a vehicle designed, tested and validated as safe to lift humans more than a couple of hundred miles from the ground. If this week’s test succeeds and the rocket later flies, the United States will be able to say that it does.But the course has not run smooth. The Space Launch System was born not on the drafting tables of engineers, but on the desks of senators. In 2010, Congress legislated into existence a launch vehicle for firing heavy things to deep space. What things? TBD. And where, exactly? No one could say for sure.Members of Congress had no particular design in mind, but they demanded that NASA rummage through crates of old space shuttle parts whenever possible to build this thing, and required that it launch by 2016. Mandated to build the big rocket, NASA cobbled together exploration programs that would use it. First, it was an asteroid rocket. Then a Mars rocket. Now, it is an Artemis moon rocket. In any event, the Space Launch System is billions of dollars over budget and five years beyond its compulsory launch date. The setbacks and slow pace that have plagued the Space Launch System stand in stark contrast to what else has happened in rocketry in the past decade. If you’ve logged on to the internet in the past five years, you’ve probably seen the spectacular launches of rockets built by SpaceX. Elon Musk’s private aerospace outfit has fired hundreds of satellites into space, and even a Tesla sports car. Its rocket boosters then return to Earth and land elegantly upright for reuse. On Sunday, one made the round trip for the ninth time. This private space program was nurtured by NASA and accelerated after the space shuttles stopped flying in 2011. Last year, SpaceX began carrying the agency’s astronauts to the International Space Station. Now the company has set its sights on landing people on the moon and Mars. But SpaceX’s rockets aren’t ready to carry astronauts beyond low-Earth orbit, and few other companies have expressed interest in this truly long-distance travel market.The Space Launch System is not NASA’s first post-Apollo attempt to build a deep space rocket for the astronaut corps. On July 20, 1989, 20 years after the Apollo 11 moon landing, President George H.W. Bush committed humankind to becoming a multiplanetary species. Later he offered a timetable: that by 2019, the 50th anniversary of that “one giant leap,” astronauts would salute the stars and stripes from Mars. Obviously, that didn’t happen. In 2004, George W. Bush made a commitment similar to his father’s. Much of the engineering that went into the Space Launch System and the Orion capsule can be traced to that now-canceled program, Constellation. In 2010, Barack Obama made his own declaration, asking NASA to use the rocket to journey to Mars. The hardware has since been absorbed by Artemis, the NASA program started by the Trump administration to land the next man and first woman on the moon before heading to the red planet. Despite the lofty ambitions of so many presidents, humans have remained mired in orbit. The ability to reach the moon is not as simple as going a little farther. The space station operates about 250 miles above Earth’s surface. The moon is about 250,000 miles away. Accordingly, after 32 years of false starts and failed programs, a successful launch of the Space Launch System will at last reopen old frontiers of human spaceflight. NASA will again have the hardware to transport humankind to other worlds. No other American rocket can send astronauts to the moon in a single launch. The Falcon Heavy, a large rocket built by SpaceX that has flown three times, is not certified to launch humans. SpaceX has instead focused its crewed deep space ambitions on Starship, a sleek, ambitious spacecraft that is under development and possibly years away from flying humans. Right now, if NASA wants to return astronauts to the moon, the Space Launch System is the only game in town, even if it costs $2 billion per launch and cannot be reused. SpaceX and Blue Origin, another private rocket company founded by Jeff Bezos of Amazon, are solving very difficult problems: how to build versatile rockets and crew vehicles that land so gently that they are reusable even with astronauts aboard.By contrast, the NASA rocket does not look like anyone’s vision of the future. That is part of what makes the Space Launch System a useful transitional product. It has no unusual engineering hurdles to leap. There is every reason to believe that once these rockets demonstrate their flight worthiness, they will work well and reliably. Until Starship or some other rocket is flying safely and regularly, NASA can continue its interplanetary endeavors knowing that in the interim, it has a working giant rocket. There is great value in that. The big rocket won’t be needed forever. It might be needed only long enough to get the first woman on the lunar surface. The commercial launch sector may be ready to take it from there. It is highly unlikely that NASA will ever again rely on rockets it has built on its own. The Space Launch System is the end of the line. If the only purpose it serves is giving the nation the time and confidence to get a private, reusable vessel spaceborne, it will have been a success. Whether the Space Launch System program ends next year or next decade, unlike the end of the space shuttle or Saturn 5, it will not be the end of a chapter, but the end of a book. NASA will be out of the rocket business. When the next generation goes to Kennedy Space Center and sees a giant old Space Launch System booster on display, the tour guide will say, “They don’t make ’em like that anymore,” and that will be true — literally.
				</p>
				<p id = "content">Published March 17, 2021   Updated Oct. 22, 2021</p>
				<h2 id = "title">"Alpha Centauri: Closest Star to Earth"</h2>
				<h3 id = "author">By: Tim Sharp</h3>
				<p id = "content">
					The closest star to Earth is a triple-star system called Alpha Centauri. The two main stars are Alpha Centauri A and Alpha Centauri B, which form a binary pair. They are about 4.35 light-years from Earth, according to NASA. The third star is called Proxima Centauri or Alpha Centauri C, and it is about 4.25 light-years from Earth, making it the closest star other than the sun. According to NASA, Alpha Centauri A and B are on average about 23 astronomical units (AU) from each other — a little more than the distance between the sun and Uranus. (An astronomical unit is the average distance between Earth and the sun, which equals 92,955,807 miles or 149,597,870 kilometers.) The closest the two stars ever come to each other is 11 astronomical units, according to NASA, and the two stars orbit a common center of gravity every 80 years.Proxima Centauri, meanwhile, is about one-fifth of a light-year or 13,000 AUs from the two other stars, a distance that makes some astronomers question whether it should even be considered part of the same system. Proxima Centauri may be passing through the system and will leave the vicinity in several million years, or it may be gravitationally bound to the binary pair. If it's bound, it has an orbital period around the other two stars of about 500,000 years.To the naked eye, the Alpha Centauri A and B shine as one, making them the third brightest "star" in our night sky. The two separate stars can be seen through a small telescope, making the system one of the finest binary stars that can be observed. Proxima Centauri is too faint to see unaided, and through a telescope it appears about four diameters of the full moon away from the other two. Alpha Centauri A, also known as Rigel Kentaurus, is a yellow star of the same type (G2) as the sun, although slightly larger, according to NASA. It is three times closer to Earth than the next nearest star like our sun, according to NASA. Alpha Centauri B is an orange K1-type star slightly smaller than the sun. Proxima Centauri is a red dwarf about one-eighth the size of the sun, according to NASA. The system is in the Southern sky and is not visible to observers above the latitude of 29 degrees north, according to EarthSky.org — a line that passes near Houston and Orlando, Fla. In the Southern Hemisphere, the Alpha Centauri system is easy to find because the cross-piece of the Southern Cross (from Delta to Beta Crucis) points the way. Its right ascension is 14h 39m 41s and its declination is minus 60 degrees 50 minutes 7 seconds.Astronomers announced in August 2016 that they had detected an Earth-size planet orbiting Proxima Centauri. The planet, known as Proxima b, is about 1.3 times more massive than Earth, which suggests that the exoplanet is a rocky world, researchers said. And Proxima b's relatively small distance from Earth makes it a particularly appealing target for scientists. The planet is also in the star's habitable zone, that just-right range of distances from a star where liquid water can exist on the surface of a body. Proxima b lies just 4.7 million miles (7.5 million km) from its host star and completes one orbit every 11.2 Earth-days. However, despite Proxima b's size and location, it's unclear from today's telescopes just how habitable the planet might be. Astronomers need to run more models and do more comparative studies to better understand how habitable the planet might be. As a start, scientists need to be able to look for signs of an atmosphere. From there, the investigators can extrapolate whether that atmosphere (if present) allows liquid water to flow on the surface. Even the surface temperature of the planet, which would also affect habitability characteristics, depends on the atmosphere. Advertisement The planet may also be so close to its star that it is tidally locked, meaning it always shows the same face to its host star, just as the moon shows only one face (the near side) to Earth. This arrangement would make one side of the planet very warm and the other very cold unless winds could distribute the heat around the planet. If that stark temperature difference does exist, it would be a severe challenge to any life.And Proxima Centauri's status as a red dwarf also likely reduces habitability. Red dwarfs are unstable stars, particularly when they are young — such stars produce a lot of stellar activity and emit charged particles, which can cause intense radiation on nearby planets. Some of this radiation can strip molecules off the top of a planet's atmosphere and thin it over time, according to 2017 studies led by the NASA Goddard Space Flight Center in Greenbelt, Maryland. Scientists are continuing to study red dwarf stars to better understand the habitability of worlds like Proxima b. (NASA's Transiting Exoplanet Survey Satellite, or TESS, is an exoplanet-hunter particularly adept at spotting planets around this category of star.) In November 2017, scientists discovered Ross 128b, another planet in the habitable zone of a red dwarf that is nearly as close to Earth as Proxima Centauri is, but that appears to be a much quieter star. However, finding out more about its atmosphere will require a next-generation ground-based telescope. (The James Webb Space Telescope, set to launch in late 2021, can't gather the necessary observations because the planet does not transit across the face of its star.) In 2019, scientists spotted what might be a second planet orbiting Proxima Centauri, although the discovery has not yet been confirmed.
				</p>
				<p id = "content">This story was updated Nov. 5, 2021 and published March 20, 2019</p>

				<h2 id = "title">"A Fragment of Our Moon May be Orbiting the Sun with Earth"</h2>
				<h3 id = "author">By: Leah Crane</h3>
				<p id = "content">
					A small piece of the moon may be orbiting the sun alongside Earth. This object, called Kamo‘oalewa, has an unexpected composition that hints it may have been chipped off the moon and tossed into orbit. Quasi-satellites like Kamo‘oalewa – of which Earth has five – travel along with a planet in similar orbits around the sun. Benjamin Sharkey and Vishnu Reddy at the University of Arizona led a team that used the Large Binocular Telescope and the Lowell Discovery Telescope, both in Arizona, to examine the spectrum of the light bouncing off Kamo‘oalewa. Their observations showed that it was unexpectedly red. “It doesn’t look like what we would have expected if it was just a ‘regular’ asteroid,” says Sharkey. “We looked at almost 2000 spectra of other near-Earth asteroids, and none of them matched.”They also compared their observations to details of several other types of asteroids that can be unexpectedly red, including those with a high metal content and those covered in small grains of dust, but none of them matched. The only close match that the researchers found was with a sample of moon rock brought back by the Apollo missions, hinting that Kamo‘oalewa may have been thrown from the moon in an impact. “It’s a kind of missing piece of the puzzle,” says Reddy. “We have meteorites on the Earth, we have holes on the moon where some of those rocks came from, and this might be the piece in between.” Determining how long it’s been travelling with Earth is a more difficult question. “We think it came off the moon. The composition seems to match, but finding out when it came off the moon or where on the moon it came off of is a tall order,” says Reddy. “The only way to do that would be to get a sample back.” The Chinese space agency is already developing such a mission, called ZhengHe, planned to launch in the mid-2020s.
				</p>
				<p id = "content">Published November 11 2021</p>

			</article>

			<aside id = "sidebar">
				<div class = "dark">
					<form class = "form-horizontal">
                        <div class = "modal-header">
                           <h4>Submit An Inquiry</h4>
                        </div>
                        <div class = "modal-body">
                           <div class = "form-group">
                              <label for = "contact-name" class = "col-lg-2 control-label">Name:</label>
                              <div class = "col-lg-10">
                                 <input type = "text" class = "form-control" id = "contact-name" placeholder = "Full Name">
                              </div>
                           </div>
                        <div class = "form-group" id = "sideForm">
                              <label for = "contact-email" class = "col-lg-2 control-label">Topic:</label>
    								<select class="country">
      								<option value="#general">General</option>
      								<option value="#articles">Articles</option>
      								<option value="#planets">Planets</option>
      								<option value = "#launches">Launches</option>
      								<option value = "#stars">Stars</option>
    								</select>
                           </div>
                        <div class = "form-group">
                              <label for = "contact-message" class = "col-lg-2 control-label">Question:</label>
                              <div class = "col-lg-10 countryTwo">
                                 <textarea class = "form-control" rows = "8" placeholder = "Limit of 500 characters"></textarea>
                              </div>
                           </div>
                        </div>
                        <div class = "modal-footer">
                           <a class = "btn btn-default" data-dismiss = "modal">Close</a>
                           <button class = "btn btn-primary" type = "submit">Send</button>                   
                        </div>
                  </form>
				</div>
			</aside>
		</div>
	</section>
	<footer>
		<p>Tejas, Praneeth, Rishvik, Ayush Copyright &copy;2021</p>
	</footer>
	<div class = "modal fade" id = "contact" role = "dialog">
            <div class = "modal-dialog">
                  <div class = "modal-content">
                     <form class = "form-horizontal">
                        <div class = "modal-header">
                           <h4>Submit An Inquiry</h4>
                        </div>
                        <div class = "modal-body">
                           <div class = "form-group">
                              <label for = "contact-name" class = "col-lg-2 control-label">Name:</label>
                              <div class = "col-lg-10">
                                 <input type = "text" class = "form-control" id = "contact-name" placeholder = "Full Name">
                              </div>
                           </div>
                        <div class = "form-group">
                              <label for = "contact-email" class = "col-lg-2 control-label">Topic:</label>
    								<select class="country" >
      								<option value="#general">General</option>
      								<option value="#articles">Articles</option>
      								<option value="#planets">Planets</option>
      								<option value = "#launches">Launches</option>
      								<option value = "#stars">Stars</option>
    								</select>
                           </div>
                        <div class = "form-group">
                              <label for = "contact-message" class = "col-lg-2 control-label">Question:</label>
                              <div class = "col-lg-10">
                                 <textarea class = "form-control" rows = "8" placeholder = "Limit of 500 characters"></textarea>
                              </div>
                           </div>
                        </div>
                        <div class = "modal-footer">
                           <a class = "btn btn-default" data-dismiss = "modal">Close</a>
                           <button class = "btn btn-primary" type = "submit">Send</button>                   
                        </div>
                  </form>
                  </div>
            </div>
      </div>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <php?
    $name = $_POST["name"];
    $tag = $_POST["tag"];
    $question = $_POST["question"];
    $command = escapeshellcmd("python addQuestion.py "+$name+" "+$tag+" "+$question);
    $output = shell_exec($command);
    echo $output;
  ?>
</body>
</html>