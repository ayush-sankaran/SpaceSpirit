import mysql.connector
import sys

print("stuff")

BOZO = mysql.connector.connect(
    host="remotemysql.com",
    user="In1wWUorV0",
    passwd="WtE0hpfL4V",
    database="In1wWUorV0"
)

cursor = BOZO.cursor()

id = 0
cursor.execute("SELECT * FROM questions")
result = cursor.fetchall()
for row in result:
    id += 1

sqlQF = "INSERT INTO questions (name, tag, question, id) VALUES (%s, %s, %s, %s)"
qInput = (sys.argv[1], sys.argv[2], sys.argv[3], id)
cursor.execute(sqlQF, qInput)
BOZO.commit()
